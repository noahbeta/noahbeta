module.exports = {
  clientId: "1232671375924265103", // The id of the discord bot
  guildId: "1218528764460404837", // The id of the discord server
  mainColor: "0077ff", // The hex color of the embeds by default
  lang: "main", // If you want to set english please set "main"


  openTicketChannelId: "1223036949368012861", // The id of the channel where the message to create a ticket will be sent
  ticketTypes: [ // You have a limit of 25 types (the limit of Discord)
    {
      codeName: "purchase", // The name need to be in lowercase
      name: "Purchase", // The name that will be displayed in the ticket
      emoji: "💳", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1223053328771055646", // The category id where the tickets will be created
      customDescription: "Please explain what you want to purchase in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "report", // The name need to be in lowercase
      name: "Report", // The name that will be displayed in the ticket
      emoji: "🛑", // The emoji of the type (can be blank)
      color: "#f8312f", // Can be a hex color or blank to use the main color
      categoryId: "1223053328771055646", // The category id where the tickets will be created
      customDescription: "Please explain your report in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "other", // The name need to be in lowercase
      name: "Other", // The name that will be displayed in the ticket
      emoji: "", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1223053328771055646", // The category id where the tickets will be created
      customDescription: "", // The custom description of the ticket type (set to blank to use the default description)
      askReason: false // If the bot should ask the reason of the ticket
    }
  ],
  ticketNameOption: "Ticket-TICKETCOUNT", // Here is all parameter: USERNAME, USERID, TICKETCOUNT
  rolesWhoHaveAccessToTheTickets: [
    "1232672468594987078", "1223053328771055646", "1222207962982908065", "1232672468594987078",
  ], // Roles who can access to the tickets
  pingRoleWhenOpened: true,
  roleToPingWhenOpenedId: "1232672468594987078", // The role to ping when a ticket is opened
  logs: true,
  logsChannelId: "", // The id of the channel where the logs will be sent
  claimButton: true,
  whoCanCloseTicket: "STAFFONLY", // STAFFONLY (roles configured at "rolesWhoHaveAccessToTheTickets") or EVERYONE
  closeButton: true, // If false the ticket can be closed only by doing /closes
  askReasonWhenClosing: true, // If false the ticket will be closed without asking the reason
  maxTicketOpened: 2 // The number of tickets the user can open while another one is already open. Set to 0 to unlimited
}
