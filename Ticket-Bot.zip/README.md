# Ticket Bot

Ticket Bot is a open source project of an ticket discord bot using


